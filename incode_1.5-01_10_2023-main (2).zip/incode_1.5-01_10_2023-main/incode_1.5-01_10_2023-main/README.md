# incode_1.5-01_10_2023

atualizações do site:
agora tem leitor de libras nas paginas principais, só teste por enquanto mas agora ja tem algo de acessibilidade no site, proximo passo é colocar o Azão e o azinho pra gente que exerga mal e o contraste tbm, é isso amigos incoders guwes se despede, até.

https://incode2023.github.io/incode_1.5-01_10_2023/
